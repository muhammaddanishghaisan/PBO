import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AplikasiKalkulator extends JFrame {
    private JTextField displayTF;
    private String currentInput = "";
    private double firstNumber = 0;
    private String operator = "";
    private boolean newInput = true;

    public AplikasiKalkulator() {
        setTitle("Aplikasi Kalkulator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));
        setResizable(false);

        // Display
        displayTF = new JTextField("0");
        displayTF.setHorizontalAlignment(JTextField.RIGHT);
        displayTF.setFont(new Font("Arial", Font.PLAIN, 20));
        displayTF.setEditable(false);
        displayTF.setBackground(new Color(255, 200, 200));
        displayTF.setPreferredSize(new Dimension(300, 50));
        add(displayTF, BorderLayout.NORTH);

        // Button Panel
        JPanel buttonPanel = new JPanel(new GridLayout(4, 5, 5, 5));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));

        String[] buttons = {
            "8", "7", "9", "+", "-",
            "4", "5", "6", "*", "/",
            "1", "2", "3", "=", "%",
            ".", "0", "C", "B", "E"
        };

        for (String text : buttons) {
            JButton btn = new JButton(text);
            btn.setFont(new Font("Arial", Font.BOLD, 16));
            btn.addActionListener(e -> buttonClicked(text));
            buttonPanel.add(btn);
        }

        add(buttonPanel, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void buttonClicked(String text) {
        switch (text) {
            case "C":
                currentInput = "";
                firstNumber = 0;
                operator = "";
                newInput = true;
                displayTF.setText("0");
                break;
            case "B":
                if (currentInput.length() > 0) {
                    currentInput = currentInput.substring(0, currentInput.length() - 1);
                    displayTF.setText(currentInput.isEmpty() ? "0" : currentInput);
                }
                break;
            case "E":
                System.exit(0);
                break;
            case "=":
                if (!operator.isEmpty() && !currentInput.isEmpty()) {
                    double secondNumber = Double.parseDouble(currentInput);
                    double result = calculate(firstNumber, secondNumber, operator);
                    displayTF.setText(result % 1 == 0 ? String.valueOf((long) result) : String.valueOf(result));
                    currentInput = displayTF.getText();
                    operator = "";
                    newInput = true;
                }
                break;
            case "+": case "-": case "*": case "/": case "%":
                if (!currentInput.isEmpty()) {
                    firstNumber = Double.parseDouble(currentInput);
                    operator = text;
                    newInput = true;
                    currentInput = "";
                }
                break;
            case ".":
                if (!currentInput.contains(".")) {
                    currentInput += ".";
                    displayTF.setText(currentInput);
                }
                break;
            default:
                if (newInput && !currentInput.isEmpty()) {
                    currentInput = text;
                    newInput = false;
                } else {
                    currentInput += text;
                }
                displayTF.setText(currentInput);
                break;
        }
    }

    private double calculate(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/": return b != 0 ? a / b : 0;
            case "%": return a % b;
            default: return 0;
        }
    }

    public static void main(String[] args) {
        new AplikasiKalkulator();
    }
}
