import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class PenentuJumlahHari extends JFrame {
    private JTextField tahunTF;
    private JComboBox<String> bulanCB;
    private JLabel hasilLabel;

    private String[] namaBulan = {
        "Januari","Februari","Maret","April","Mei","Juni",
        "Juli","Agustus","September","Oktober","November","Desember"
    };

    public PenentuJumlahHari() {
        setTitle("Aplikasi Penentu Jumlah Hari");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));
        setSize(420, 300);

        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setBorder(BorderFactory.createTitledBorder("Aplikasi Penentu Jumlah Hari"));
        mainPanel.setLayout(new GridLayout(3, 1, 5, 5));
        mainPanel.setBackground(new Color(144, 238, 144));

        // Input tahun
        JPanel tahunPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        tahunPanel.setBackground(new Color(144, 238, 144));
        JLabel tahunLbl = new JLabel("Tahun");
        tahunLbl.setFont(new Font("Arial", Font.BOLD, 13));
        tahunTF = new JTextField(10);
        tahunPanel.add(tahunLbl);
        tahunPanel.add(tahunTF);

        // Input bulan
        JPanel bulanPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bulanPanel.setBackground(new Color(144, 238, 144));
        JLabel bulanLbl = new JLabel("Bulan");
        bulanLbl.setFont(new Font("Arial", Font.BOLD, 13));
        bulanCB = new JComboBox<>(namaBulan);
        bulanPanel.add(bulanLbl);
        bulanPanel.add(bulanCB);

        // Hasil
        JPanel hasilPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        hasilPanel.setBackground(new Color(255, 255, 200));
        hasilLabel = new JLabel("jLabel3");
        hasilLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        hasilPanel.add(hasilLabel);

        mainPanel.add(tahunPanel);
        mainPanel.add(bulanPanel);
        mainPanel.add(hasilPanel);
        add(mainPanel, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton hitungBtn = new JButton("Hitung");
        JButton hapusBtn = new JButton("Hapus");
        JButton simpanBtn = new JButton("Simpan");
        JButton keluarBtn = new JButton("Keluar");

        hitungBtn.addActionListener(e -> hitungBTActionPerformed());
        hapusBtn.addActionListener(e -> hapusBTActionPerformed());
        simpanBtn.addActionListener(e -> simpanBTActionPerformed());
        keluarBtn.addActionListener(e -> keluarBTActionPerformed());

        btnPanel.add(hitungBtn);
        btnPanel.add(hapusBtn);
        btnPanel.add(simpanBtn);
        btnPanel.add(keluarBtn);
        add(btnPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void hitungBTActionPerformed() {
        try {
            int tahun = Integer.parseInt(tahunTF.getText());
            String bulan = (String) bulanCB.getSelectedItem();
            HitungHari hh = new HitungHari(tahun, bulan);
            int jumlah = hh.hitung();
            hasilLabel.setText("Jumlah hari pada bulan " + bulan + " tahun " + tahun + " adalah " + jumlah);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Masukkan tahun yang valid!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void hapusBTActionPerformed() {
        tahunTF.setText("");
        bulanCB.setSelectedIndex(0);
        hasilLabel.setText("jLabel3");
        tahunTF.requestFocus();
    }

    private void simpanBTActionPerformed() {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("jumlahhari.txt"));
            out.write(hasilLabel.getText());
            out.close();
            JOptionPane.showMessageDialog(null, "Berhasil disimpan dalam file");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private void keluarBTActionPerformed() {
        int reply = JOptionPane.showConfirmDialog(null, "Yakin ingin keluar?",
                "Konfirmasi Keluar Aplikasi", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new PenentuJumlahHari();
    }
}
