public class HitungHari {
    private int tahun;
    private String bulan;

    public HitungHari(int tahun, String bulan) {
        this.tahun = tahun;
        this.bulan = bulan;
    }

    public int hitung() {
        switch (bulan) {
            case "Januari": case "Maret": case "Mei": case "Juli":
            case "Agustus": case "Oktober": case "Desember":
                return 31;
            case "April": case "Juni": case "September": case "November":
                return 30;
            case "Februari":
                return isTahunKabisat(tahun) ? 29 : 28;
            default:
                return 0;
        }
    }

    private boolean isTahunKabisat(int t) {
        return (t % 4 == 0 && t % 100 != 0) || (t % 400 == 0);
    }
}
