/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nakamura June
 */
public class Bingo {
    public Bingo() {
        printLyrics();
    }

    public void printLyrics() {
        String name = "B-I-N-G-O";
        String[] claps = {"B", "I", "N", "G", "O"};
        
        for (int i = 0; i <= 5; i++) {
            System.out.println("There was a farmer who had a dog,");
            System.out.println("And Bingo was his name-o.");
            
            StringBuilder row = new StringBuilder();
            for (int j = 0; j < 5; j++) {
                if (j < i) {
                    row.append("(clap)");
                } else {
                    row.append(claps[j]);
                }
                if (j < 4) row.append("-");
            }

            for (int k = 0; k < 3; k++) {
                System.out.println(row);
            }
            
            System.out.println("And Bingo was his name-o.\n");
        }
    }

    public static void main(String[] args) {
        new Bingo();
    }
}