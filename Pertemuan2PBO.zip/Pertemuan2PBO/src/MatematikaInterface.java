/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Nakamura June
 */
interface InterfaceMatematika {
    void pertambahan(int a, int b);
    void pengurangan(int a, int b);
    void perkalian(int a, int b);
    void pembagian(int a, int b);
}

public class MatematikaInterface implements InterfaceMatematika {
    public void pertambahan(int a, int b) {
        System.out.println("Pertambahan : " + (a + b));
    }
    public void pengurangan(int a, int b) {
        System.out.println("Pengurangan : " + (a - b));
    }
    public void perkalian(int a, int b) {
        System.out.println("Perkalian   : " + (a * b));
    }
    public void pembagian(int a, int b) {
        System.out.println("Pembagian   : " + (a / b));
    }
}
