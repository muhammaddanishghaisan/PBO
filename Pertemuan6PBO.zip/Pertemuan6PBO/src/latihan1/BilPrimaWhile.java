package latihan1;

/**
 * Latihan 1a - While
 * Menghitung deret bilangan prima dan bukan prima dari 0-20
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class BilPrimaWhile {
    public static void main(String[] args) {
        System.out.println("=== Bilangan Prima & Bukan Prima (0-20) | WHILE ===");
        int i = 0;
        while (i <= 20) {
            boolean prima = (i >= 2);
            int j = 2;
            while (j <= Math.sqrt(i)) {
                if (i % j == 0) {
                    prima = false;
                    break;
                }
                j++;
            }
            if (prima) {
                System.out.println(i + " -> Prima");
            } else {
                System.out.println(i + " -> Bukan Prima");
            }
            i++;
        }
    }
}
