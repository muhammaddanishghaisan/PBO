package latihan1;

/**
 * Latihan 1d - Do-While
 * Lagu "Anak Ayam Turun N"
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class AnakAyamDoWhile {
    public static void main(String[] args) {
        int i = 10;
        System.out.println("=== Lagu Anak Ayam Turun " + i + " | DO-WHILE ===");
        do {
            System.out.println("Anak ayam turun " + i);
            System.out.println("Mati satu tinggal " + (i - 1));
            i--;
        } while (i >= 1);
        System.out.println("Habis semua induknya menangis");
    }
}
