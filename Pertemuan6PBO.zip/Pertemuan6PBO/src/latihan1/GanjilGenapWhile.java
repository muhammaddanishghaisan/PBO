package latihan1;

/**
 * Latihan 1b - While
 * Menghitung deret bilangan ganjil dan genap dari 0-20
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class GanjilGenapWhile {
    public static void main(String[] args) {
        System.out.println("=== Bilangan Ganjil & Genap (0-20) | WHILE ===");
        int i = 0;
        while (i <= 20) {
            if (i % 2 == 0) {
                System.out.println(i + " -> Genap");
            } else {
                System.out.println(i + " -> Ganjil");
            }
            i++;
        }
    }
}
