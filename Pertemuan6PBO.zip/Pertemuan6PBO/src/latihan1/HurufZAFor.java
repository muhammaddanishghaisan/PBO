package latihan1;

/**
 * Latihan 1c - For
 * Menampilkan huruf Z sampai A
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class HurufZAFor {
    public static void main(String[] args) {
        System.out.println("=== Huruf Z sampai A | FOR ===");
        for (char c = 'Z'; c >= 'A'; c--) {
            System.out.print(c + " ");
        }
        System.out.println();
    }
}
