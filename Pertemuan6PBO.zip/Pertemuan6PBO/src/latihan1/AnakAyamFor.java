package latihan1;

/**
 * Latihan 1d - For
 * Lagu "Anak Ayam Turun N"
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class AnakAyamFor {
    public static void main(String[] args) {
        int n = 10;
        System.out.println("=== Lagu Anak Ayam Turun " + n + " | FOR ===");
        for (int i = n; i >= 1; i--) {
            System.out.println("Anak ayam turun " + i);
            System.out.println("Mati satu tinggal " + (i - 1));
        }
        System.out.println("Habis semua induknya menangis");
    }
}
