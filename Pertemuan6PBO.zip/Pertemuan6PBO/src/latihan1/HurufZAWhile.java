package latihan1;

/**
 * Latihan 1c - While
 * Menampilkan huruf Z sampai A
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class HurufZAWhile {
    public static void main(String[] args) {
        System.out.println("=== Huruf Z sampai A | WHILE ===");
        char c = 'Z';
        while (c >= 'A') {
            System.out.print(c + " ");
            c--;
        }
        System.out.println();
    }
}
