package latihan1;

/**
 * Latihan 1a - For
 * Menghitung deret bilangan prima dan bukan prima dari 0-20
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class BilPrimaFor {
    public static void main(String[] args) {
        System.out.println("=== Bilangan Prima & Bukan Prima (0-20) | FOR ===");
        for (int i = 0; i <= 20; i++) {
            boolean prima = (i >= 2);
            for (int j = 2; j <= Math.sqrt(i); j++) {
                if (i % j == 0) {
                    prima = false;
                    break;
                }
            }
            if (prima) {
                System.out.println(i + " -> Prima");
            } else {
                System.out.println(i + " -> Bukan Prima");
            }
        }
    }
}
