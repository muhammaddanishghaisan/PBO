package latihan1;

/**
 * Latihan 1a - Do-While
 * Menghitung deret bilangan prima dan bukan prima dari 0-20
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class BilPrimaDoWhile {
    public static void main(String[] args) {
        System.out.println("=== Bilangan Prima & Bukan Prima (0-20) | DO-WHILE ===");
        int i = 0;
        do {
            boolean prima = (i >= 2);
            if (i >= 2) {
                int j = 2;
                do {
                    if (i % j == 0) {
                        prima = false;
                    }
                    j++;
                } while (j <= Math.sqrt(i));
            }
            if (prima) {
                System.out.println(i + " -> Prima");
            } else {
                System.out.println(i + " -> Bukan Prima");
            }
            i++;
        } while (i <= 20);
    }
}
