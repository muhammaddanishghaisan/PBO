package latihan1;

/**
 * Latihan 1c - Do-While
 * Menampilkan huruf Z sampai A
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class HurufZADoWhile {
    public static void main(String[] args) {
        System.out.println("=== Huruf Z sampai A | DO-WHILE ===");
        char c = 'Z';
        do {
            System.out.print(c + " ");
            c--;
        } while (c >= 'A');
        System.out.println();
    }
}
