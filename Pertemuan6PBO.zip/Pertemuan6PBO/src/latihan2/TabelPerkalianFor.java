package latihan2;

import java.util.Scanner;

/**
 * Latihan 2 - For
 * Tabel perkalian N x N (n <= 10)
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class TabelPerkalianFor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Masukkan nilai n (maks 10): ");
        int n = sc.nextInt();

        if (n < 1 || n > 10) {
            System.out.println("Nilai n harus antara 1 sampai 10!");
            sc.close();
            return;
        }

        System.out.println("=== Tabel Perkalian " + n + " x " + n + " | FOR ===");

        // Header kolom
        System.out.printf("%5s", "");
        for (int j = 1; j <= n; j++) {
            System.out.printf("%5d", j);
        }
        System.out.println();

        // Separator
        System.out.println("     " + "-----".repeat(n));

        // Baris perkalian
        for (int i = 1; i <= n; i++) {
            System.out.printf("%5d", i);
            for (int j = 1; j <= n; j++) {
                System.out.printf("%5d", i * j);
            }
            System.out.println();
        }

        sc.close();
    }
}
