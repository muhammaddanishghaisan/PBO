package latihan2;

import java.util.Scanner;

/**
 * Latihan 2 - Do-While
 * Tabel perkalian N x N (n <= 10)
 * Nama  : Muhammad Danish Ghaisan
 * NPM   : 2510631170044
 * Kelas : 2B
 */
public class TabelPerkalianDoWhile {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Masukkan nilai n (maks 10): ");
        int n = sc.nextInt();

        if (n < 1 || n > 10) {
            System.out.println("Nilai n harus antara 1 sampai 10!");
            sc.close();
            return;
        }

        System.out.println("=== Tabel Perkalian " + n + " x " + n + " | DO-WHILE ===");

        // Header kolom
        System.out.printf("%5s", "");
        int j = 1;
        do {
            System.out.printf("%5d", j);
            j++;
        } while (j <= n);
        System.out.println();

        // Separator
        System.out.println("     " + "-----".repeat(n));

        // Baris perkalian
        int i = 1;
        do {
            System.out.printf("%5d", i);
            j = 1;
            do {
                System.out.printf("%5d", i * j);
                j++;
            } while (j <= n);
            System.out.println();
            i++;
        } while (i <= n);

        sc.close();
    }
}
