import java.util.Scanner;

public class TokoSerbaAda {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Data barang berdasarkan kode
        String[] kodeRef    = {"a001", "a002", "a003"};
        String[] namaRef    = {"Buku", "Pensil", "Pulpen"};
        int[]    hargaRef   = {3000, 4000, 5000};

        System.out.println("TOKO SERBA ADA");
        System.out.println("**************");

        System.out.print("Masukkan Item Barang : ");
        int n = input.nextInt();

        String[] kode    = new String[n];
        int[]    jumlahBeli = new int[n];
        String[] namaBarang = new String[n];
        int[]    harga   = new int[n];
        int[]    jumlahBayar = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Data ke " + (i + 1));
            System.out.print("   Masukkan Kode        : ");
            kode[i] = input.next();
            System.out.print("   Masukkan jumlah Beli : ");
            jumlahBeli[i] = input.nextInt();

            // Tentukan nama dan harga berdasarkan kode
            namaBarang[i] = "Tidak Dikenal";
            harga[i] = 0;
            for (int j = 0; j < kodeRef.length; j++) {
                if (kode[i].equalsIgnoreCase(kodeRef[j])) {
                    namaBarang[i] = namaRef[j];
                    harga[i] = hargaRef[j];
                    break;
                }
            }
            jumlahBayar[i] = harga[i] * jumlahBeli[i];
        }

        // Output header
        System.out.println("\nTOKO SERBA ADA");
        System.out.println("**********************");
        System.out.printf("%-4s %-12s %-15s %-8s %-14s %s%n",
                "No", "Kode Barang", "Nama Barang", "Harga", "Jumlah Beli", "Jumlah Bayar");
        System.out.println("=".repeat(65));

        int totalBayar = 0;
        for (int i = 0; i < n; i++) {
            System.out.printf("%-4d %-12s %-15s %-8d %-14d %d%n",
                    (i + 1), kode[i], namaBarang[i], harga[i], jumlahBeli[i], jumlahBayar[i]);
            totalBayar += jumlahBayar[i];
        }

        System.out.println("=".repeat(65));
        System.out.printf("%-4s %-12s %-15s %-8s %-14s %d%n",
                "Total Bayar", "", "", "", "", totalBayar);
        System.out.println("=".repeat(65));

        input.close();
    }
}
