import java.util.Scanner;

public class PotongHarga {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Total pembelian Rp. : ");
        double totalBeli = input.nextDouble();

        double potongan;

        if (totalBeli < 50000) {
            potongan = totalBeli * 0.05;
        } else {
            potongan = totalBeli * 0.20;
        }

        double bayar = totalBeli - potongan;

        System.out.println("Besarnya potongan Rp. " + potongan);
        System.out.println("Jumlah yang harus dibayarkan Rp. " + bayar);
    }
}
