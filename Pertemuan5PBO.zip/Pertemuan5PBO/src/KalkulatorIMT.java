import java.util.Scanner;

public class KalkulatorIMT {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Berat Badan (kg) : ");
        double berat = input.nextDouble();
        System.out.print("Tinggi Badan (m) : ");
        double tinggi = input.nextDouble();

        double imt = berat / (tinggi * tinggi);

        String kriteria;

        if (imt < 18.5) {
            kriteria = "Berat Badan Kurang";
        } else if (imt <= 24.9) {
            kriteria = "Berat Badan Ideal";
        } else if (imt <= 29.9) {
            kriteria = "Berat Badan Lebih";
        } else if (imt <= 39.9) {
            kriteria = "Gemuk";
        } else {
            kriteria = "Sangat Gemuk";
        }

        System.out.printf("Nilai IMT : %.2f%n", imt);
        System.out.println("Kriteria  : " + kriteria);
    }
}
