package polymorphismproject;

/**
 * Class Main - titik masuk eksekusi program
 * Demonstrasi polymorphism melalui upcasting dan dynamic method dispatch
 * @author Nakamura June
 */
public class Main {
    public static void main(String[] args) {
        // Upcasting: objek subclass disimpan dalam variabel bertipe superclass
        Bangun3D balok = new Balok(10, 5, 4);
        Bangun3D kubus = new Kubus(6);

        System.out.println("==============================");
        System.out.println("        DATA BALOK            ");
        System.out.println("==============================");
        System.out.println(balok.getInfo());

        System.out.println("\n==============================");
        System.out.println("        DATA KUBUS            ");
        System.out.println("==============================");
        System.out.println(kubus.getInfo());
    }
}
