package polymorphismproject;

/**
 * Subclass Kubus - mewarisi Bangun3D dan mengoverride method perhitungan
 * @author Nakamura June
 */
public class Kubus extends Bangun3D {
    private double sisi;

    public Kubus(double sisi) {
        super("Kubus");
        this.sisi = sisi;
    }

    @Override
    public double hitungVolume() {
        return sisi * sisi * sisi;
    }

    @Override
    public double hitungLuasPermukaan() {
        return 6 * sisi * sisi;
    }

    @Override
    public String getInfo() {
        return super.getInfo()
             + "\nSisi             : " + sisi;
    }
}
