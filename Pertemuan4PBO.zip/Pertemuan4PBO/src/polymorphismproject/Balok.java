package polymorphismproject;

/**
 * Subclass Balok - mewarisi Bangun3D dan mengoverride method perhitungan
 * @author Nakamura June
 */
public class Balok extends Bangun3D {
    private double panjang, lebar, tinggi;

    public Balok(double panjang, double lebar, double tinggi) {
        super("Balok");
        this.panjang = panjang;
        this.lebar = lebar;
        this.tinggi = tinggi;
    }

    @Override
    public double hitungVolume() {
        return panjang * lebar * tinggi;
    }

    @Override
    public double hitungLuasPermukaan() {
        return 2 * ((panjang * lebar) + (panjang * tinggi) + (lebar * tinggi));
    }

    @Override
    public String getInfo() {
        return super.getInfo()
             + "\nPanjang          : " + panjang
             + "\nLebar            : " + lebar
             + "\nTinggi           : " + tinggi;
    }
}
