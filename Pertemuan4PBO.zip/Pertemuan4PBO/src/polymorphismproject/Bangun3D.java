package polymorphismproject;

/**
 * Superclass Bangun3D - class induk yang mendefinisikan method dasar
 * @author Nakamura June
 */
public class Bangun3D {
    protected String nama;

    public Bangun3D(String nama) {
        this.nama = nama;
    }

    public double hitungVolume() {
        return 0;
    }

    public double hitungLuasPermukaan() {
        return 0;
    }

    public String getInfo() {
        return "Nama Bangun : " + nama
             + "\nVolume           : " + hitungVolume()
             + "\nLuas Permukaan   : " + hitungLuasPermukaan();
    }
}
