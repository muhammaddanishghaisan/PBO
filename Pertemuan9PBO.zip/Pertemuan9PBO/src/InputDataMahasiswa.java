import java.util.ArrayList;

public class InputDataMahasiswa {
    ArrayList<Mahasiswa> listmahasiswa;

    public InputDataMahasiswa() {
        listmahasiswa = new ArrayList<>();
    }

    public void insertData(String NIM, String Nama, String Alamat, String MataKuliah,
                           double n1, double n2, double n3, double n4, double n5) {
        Mahasiswa mhs = new Mahasiswa(NIM, Nama, Alamat, MataKuliah, n1, n2, n3, n4, n5);
        listmahasiswa.add(mhs);
    }

    public ArrayList<Mahasiswa> getALL() {
        return listmahasiswa;
    }

    public void deleteData(int index) {
        if (index >= 0 && index < listmahasiswa.size()) {
            listmahasiswa.remove(index);
        }
    }
}
