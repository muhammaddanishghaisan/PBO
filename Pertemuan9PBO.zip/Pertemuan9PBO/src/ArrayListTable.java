import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ArrayListTable extends JFrame {

    // === Input fields kiri ===
    private JTextField nimTF, namaTF, alamatTF, matakuliahTF;

    // === Input fields nilai ===
    private JTextField nilai1TF, nilai2TF, nilai3TF, nilai4TF, nilai5TF;
    private JTextField nilaiAkhirTF;

    // === Buttons ===
    private JButton simpanBT, hapusBT;

    // === Table ===
    private JTable mahasiswaTB;
    private DefaultTableModel modelmahasiswa;

    // === Data ===
    private InputDataMahasiswa datamahasiswa;

    public ArrayListTable() {
        datamahasiswa = new InputDataMahasiswa();
        initComponents();
        viewDataTabel();
    }

    private void initComponents() {
        setTitle("Data Mahasiswa");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(750, 500);
        setLocationRelativeTo(null);
        setLayout(null);

        // ── Label & TextField kiri ──
        int lx = 30, tx = 130, fw = 180, fh = 25, gap = 35;
        int y = 30;

        addLabel("NIM", lx, y);
        nimTF = addField(tx, y, fw, fh);
        y += gap;

        addLabel("Nama", lx, y);
        namaTF = addField(tx, y, fw, fh);
        y += gap;

        addLabel("Alamat", lx, y);
        alamatTF = addField(tx, y, fw, fh);
        y += gap;

        addLabel("Mata Kuliah", lx, y);
        matakuliahTF = addField(tx, y, fw, fh);
        y += gap;

        // ── Label & TextField nilai (kanan) ──
        int lx2 = 350, tx2 = 500, fw2 = 160;
        int y2 = 30;

        addLabel("Nilai 1 [10%]", lx2, y2);
        nilai1TF = addField(tx2, y2, fw2, fh);
        y2 += gap;

        addLabel("Nilai 2 [15%]", lx2, y2);
        nilai2TF = addField(tx2, y2, fw2, fh);
        y2 += gap;

        addLabel("Nilai 3 - UTS[25%]", lx2, y2);
        nilai3TF = addField(tx2, y2, fw2, fh);
        y2 += gap;

        addLabel("Nilai 4 [15%]", lx2, y2);
        nilai4TF = addField(tx2, y2, fw2, fh);
        y2 += gap;

        addLabel("Nilai 5 [35%]", lx2, y2);
        nilai5TF = addField(tx2, y2, fw2, fh);
        y2 += gap;

        addLabel("Nilai Akhir", lx2, y2);
        nilaiAkhirTF = addField(tx2, y2, fw2, fh);
        nilaiAkhirTF.setEditable(false);
        nilaiAkhirTF.setBackground(new Color(230, 230, 230));

        // ── Tombol Simpan & Hapus ──
        simpanBT = new JButton("Simpan");
        simpanBT.setBounds(tx, y + 5, 85, 28);
        add(simpanBT);

        hapusBT = new JButton("Hapus");
        hapusBT.setBounds(tx + 95, y + 5, 85, 28);
        add(hapusBT);

        // ── Tabel ──
        String[] kolom = {"NIM", "Nama", "Alamat", "Mata Kuliah", "Nilai Akhir"};
        modelmahasiswa = new DefaultTableModel(kolom, 0);
        mahasiswaTB = new JTable(modelmahasiswa);
        mahasiswaTB.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(mahasiswaTB);
        scroll.setBounds(20, 230, 700, 220);
        add(scroll);

        // ── Hitung otomatis nilai akhir saat field nilai diubah ──
        KeyAdapter hitungListener = new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                hitungNilaiAkhir();
            }
        };
        nilai1TF.addKeyListener(hitungListener);
        nilai2TF.addKeyListener(hitungListener);
        nilai3TF.addKeyListener(hitungListener);
        nilai4TF.addKeyListener(hitungListener);
        nilai5TF.addKeyListener(hitungListener);

        // ── Action Listeners ──
        simpanBT.addActionListener(e -> simpanAction());
        hapusBT.addActionListener(e -> hapusAction());
    }

    private JLabel addLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 160, 25);
        add(lbl);
        return lbl;
    }

    private JTextField addField(int x, int y, int w, int h) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, w, h);
        add(tf);
        return tf;
    }

    private void hitungNilaiAkhir() {
        try {
            double n1 = parseNilai(nilai1TF.getText());
            double n2 = parseNilai(nilai2TF.getText());
            double n3 = parseNilai(nilai3TF.getText());
            double n4 = parseNilai(nilai4TF.getText());
            double n5 = parseNilai(nilai5TF.getText());
            double na = (n1 * 0.10) + (n2 * 0.15) + (n3 * 0.25) + (n4 * 0.15) + (n5 * 0.35);
            nilaiAkhirTF.setText(String.format("%.2f", na));
        } catch (NumberFormatException ex) {
            nilaiAkhirTF.setText("");
        }
    }

    private double parseNilai(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        return Double.parseDouble(s.trim());
    }

    public final void viewDataTabel() {
        String[] namakolom = {"NIM", "Nama", "Alamat", "Mata Kuliah", "Nilai Akhir"};
        Object[][] obj = new Object[datamahasiswa.getALL().size()][5];
        int i = 0;
        for (Mahasiswa mhs : datamahasiswa.getALL()) {
            obj[i][0] = mhs.getNIM();
            obj[i][1] = mhs.getNama();
            obj[i][2] = mhs.getAlamat();
            obj[i][3] = mhs.getMataKuliah();
            obj[i][4] = String.format("%.2f", mhs.getNilaiAkhir());
            i++;
        }
        modelmahasiswa = new DefaultTableModel(obj, namakolom);
        mahasiswaTB.setModel(modelmahasiswa);
    }

    public void clearTextField() {
        nimTF.setText("");
        namaTF.setText("");
        alamatTF.setText("");
        matakuliahTF.setText("");
        nilai1TF.setText("");
        nilai2TF.setText("");
        nilai3TF.setText("");
        nilai4TF.setText("");
        nilai5TF.setText("");
        nilaiAkhirTF.setText("");
        nimTF.requestFocus();
    }

    private void simpanAction() {
        String nim = nimTF.getText().trim();
        String nama = namaTF.getText().trim();
        String alamat = alamatTF.getText().trim();
        String mk = matakuliahTF.getText().trim();

        if (nim.isEmpty() || nama.isEmpty()) {
            JOptionPane.showMessageDialog(this, "NIM dan Nama harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double n1 = parseNilai(nilai1TF.getText());
            double n2 = parseNilai(nilai2TF.getText());
            double n3 = parseNilai(nilai3TF.getText());
            double n4 = parseNilai(nilai4TF.getText());
            double n5 = parseNilai(nilai5TF.getText());

            datamahasiswa.insertData(nim, nama, alamat, mk, n1, n2, n3, n4, n5);
            viewDataTabel();
            clearTextField();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Nilai harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void hapusAction() {
        int row = mahasiswaTB.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris yang ingin dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        datamahasiswa.deleteData(row);
        viewDataTabel();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ArrayListTable().setVisible(true);
        });
    }
}
