public class Mahasiswa {
    private String NIM, Nama, Alamat, MataKuliah;
    private double NilaiAkhir;

    public Mahasiswa(String NIM, String Nama, String Alamat, String MataKuliah,
                     double nilai1, double nilai2, double nilai3, double nilai4, double nilai5) {
        this.NIM = NIM;
        this.Nama = Nama;
        this.Alamat = Alamat;
        this.MataKuliah = MataKuliah;
        // Nilai Akhir = 10% + 15% + 25% + 15% + 35%
        this.NilaiAkhir = (nilai1 * 0.10) + (nilai2 * 0.15) + (nilai3 * 0.25)
                        + (nilai4 * 0.15) + (nilai5 * 0.35);
    }

    public String getNIM()        { return NIM; }
    public String getNama()       { return Nama; }
    public String getAlamat()     { return Alamat; }
    public String getMataKuliah() { return MataKuliah; }
    public double getNilaiAkhir() { return NilaiAkhir; }
}
