/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nakamura June
 */
public class Mahasiswa {
void membaca() {
        System.out.println("Mahasiswa sedang membaca buku di perpustakaan.");
    }

    void nyontek() {
        System.out.println("Mahasiswa dilarang nyontek saat ujian!"); 
    }

    void modifikasi() {
        System.out.println("Mahasiswa sedang memodifikasi kode program."); 
    }
}
