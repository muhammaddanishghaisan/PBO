/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nakamura June
 */
public class DemoNilai {
    public static void main(String[] args) {
        Nilai mhsNilai = new Nilai(); 
        mhsNilai.Nilai("2341234", "Budi Santoso", 80, 85, 75, 90); 
        mhsNilai.CetakNilai(); 
    }
}
