/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nakamura June
 */
public class Nilai {
    String nim, nama; 
    double nAbsen, nTugas, nUTS, nUAS, nAkhir; 

    void Nilai(String nim, String nama, double absen, double tugas, double uts, double uas) {
        this.nim = nim; 
        this.nama = nama; 
        this.nAbsen = absen; 
        this.nTugas = tugas;
        this.nUTS = uts; 
        this.nUAS = uas; 
        this.nAkhir = (nAbsen * 0.1) + (nTugas * 0.2) + (nUTS * 0.3) + (nUAS * 0.4);
    }
    void CetakNilai() {
        System.out.println("NIM              : " + nim); 
        System.out.println("Nama             : " + nama); 
        System.out.println("Nilai Absen [10%]: " + nAbsen); 
        System.out.println("Nilai Tugas [20%]: " + nTugas); 
        System.out.println("Nilai UTS   [30%]: " + nUTS); 
        System.out.println("Nilai UAS   [40%]: " + nUAS); 
        System.out.println("Nilai Akhir      : " + nAkhir); 
    }
}
