/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nakamura June
 */
public class MatematikaInheritance {
    public static void main(String[] args) {
        Matematika2 mtk = new Matematika2();
        System.out.println("Pertambahan : " + mtk.pertambahan(20, 10));
        System.out.println("Pengurangan : " + mtk.pengurangan(10, 5));
        System.out.println("Perkalian   : " + mtk.perkalian(10, 3));
        System.out.println("Pembagian   : " + mtk.pembagian(20, 2));
        System.out.println("Modulus     : " + mtk.modulus(20, 3));
    }
}